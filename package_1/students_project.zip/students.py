import classes

st1 = classes.Student('Male', 30, 'Steve', 'Jobs', 'AN142')
st2 = classes.Student('Female', 25, 'Liza', 'Taylor', 'AN145')
# st3 = classes.Student('Male', 30, 'Steve', 'Jobs', 'AN142')
#
# assert gr.find_student('Jobs') == st1  # 'Steve Jobs'
# assert gr.find_student('Jobs2') is None


